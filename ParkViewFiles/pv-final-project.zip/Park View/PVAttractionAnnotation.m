#import "PVAttractionAnnotation.h"

@implementation PVAttractionAnnotation

@end
