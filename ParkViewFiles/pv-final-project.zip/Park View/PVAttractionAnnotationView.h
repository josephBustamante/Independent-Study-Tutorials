#import <MapKit/MapKit.h>

@interface PVAttractionAnnotationView : MKAnnotationView

@end
