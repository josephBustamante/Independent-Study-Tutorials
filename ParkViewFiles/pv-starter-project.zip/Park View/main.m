
#import <UIKit/UIKit.h>

#import "PVAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PVAppDelegate class]));
    }
}
